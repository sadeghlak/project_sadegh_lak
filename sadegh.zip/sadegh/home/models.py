from django.db import models

class HomeContent(models.Model):
    title = models.CharField(max_length=200)
    subtitle = models.CharField(max_length=300, blank=True)
    banner_image = models.ImageField(upload_to='home_banners/', blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)