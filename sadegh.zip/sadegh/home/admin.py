from django.contrib import admin
from .models import HomeContent

admin.site.register(HomeContent)
