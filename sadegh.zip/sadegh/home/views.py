from django.shortcuts import render
from blog.views import blog_list, post_detail

# Create your views here.
def home(request):
    return render(request, template_name='home/index.html')