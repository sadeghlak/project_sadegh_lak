from django.db import models
from django.utils import timezone

class BlogPost(models.Model):
    title = models.CharField(max_length=200, verbose_name="عنوان")
    content = models.TextField(verbose_name="متن محتوا")
    author = models.CharField(max_length=100, verbose_name="نویسنده")
    image = models.ImageField(upload_to='blog_images/', blank=True, null=True, verbose_name="عکس")
    publish_date = models.DateTimeField(default=timezone.now, verbose_name="تاریخ انتشار")

    def __str__(self):
        return self.title
